

$(document).ready(function () {


	 })



 function login()
              {


                   window.setTimeout(function () {
                            window.location.href = 'login';
                        }, 0);


              };


 function register()
              {


                   window.setTimeout(function () {
                            window.location.href = 'register';
                        }, 0);


              };